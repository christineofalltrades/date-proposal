# Date Proposal (Browser Edition)

This is a single-file web app that runs in any modern browser—no Java required. 
Perfect for a QR code: it opens, and your partner can tap buttons to respond. 💖

## How to Publish (GitHub Pages)
1. Create a new GitHub repo (e.g., `date-proposal`).
2. Upload `index.html` to the repo root and commit.
3. In repo Settings → Pages, set **Source** to **Deploy from a branch**, and choose `main` and `/ (root)`.
4. After it builds, your site will be live at `https://YOUR-USERNAME.github.io/date-proposal/`.

## Make a QR Code
- In Chrome: open your live page → click the address bar QR icon (or Share → Create QR Code) → download the PNG.
- Or use any QR generator and paste your live URL.

## Test Locally (no internet)
Just open `index.html` by double-clicking it. If some browsers restrict clipboard, copy the link manually if needed.

## Optional Customization
- Change colors in the `<style>` `:root` section.
- Edit text in the HTML to make it more personal.
- You can add your photo, custom emojis, or a background song (be considerate about autoplay!).

Enjoy! 💌
